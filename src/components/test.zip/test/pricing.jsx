import React from "react";
import { Check, ChevronRight, Linkedin, Github, Instagram } from "lucide-react";
import Footer from "./Footer";
import Header from "./Header";

const PricingPage = () => {
  return (
    <>
      <Header />

      {/* Entire Page Gradient Background */}
      <div
        className="min-h-screen py-12 px-4"
        style={{
          background: `
            radial-gradient(
              circle at center,
              transparent 0%,
              transparent 30%,
              rgba(255, 255, 255, 0.6) 70%,
              rgba(255, 255, 255, 0.6) 100%
            ),
            linear-gradient(
              to right,
              #e2eef6 0%,
              #d3def8 45%,
              #c8d3f8 65%,
              #dcd6f7 85%,
              #f1eef6 100%
            )`,
        }}
      >
        <div className="max-w-7xl mx-auto">
          {/* Hero Section */}
          <div className="relative w-full h-80 overflow-hidden rounded-3xl mb-8">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-600 via-blue-500 to-cyan-400">
              <div className="absolute inset-0">
                <div className="absolute -top-20 -left-20 w-96 h-96 bg-gradient-to-br from-purple-400/30 to-transparent rounded-full blur-3xl transform rotate-12"></div>
                <div className="absolute top-10 left-1/4 w-80 h-80 bg-gradient-to-br from-blue-400/40 to-transparent rounded-full blur-2xl transform -rotate-45"></div>
                <div className="absolute -bottom-10 left-1/3 w-72 h-72 bg-gradient-to-br from-cyan-400/30 to-transparent rounded-full blur-2xl transform rotate-45"></div>
                <div className="absolute top-20 right-20 w-96 h-96 bg-gradient-to-br from-purple-500/20 to-transparent rounded-full blur-3xl transform -rotate-12"></div>
                <div className="absolute bottom-0 right-0 w-80 h-80 bg-gradient-to-br from-blue-300/25 to-transparent rounded-full blur-2xl transform rotate-30"></div>
                <div className="absolute top-16 left-32 w-64 h-48 bg-gradient-to-br from-white/10 to-transparent rounded-full blur-xl transform rotate-45 skew-x-12"></div>
                <div className="absolute bottom-16 right-32 w-56 h-40 bg-gradient-to-br from-purple-300/20 to-transparent rounded-full blur-xl transform -rotate-30 skew-y-12"></div>
              </div>
              <div className="absolute inset-0 bg-gradient-to-r from-purple-900/20 to-blue-900/20"></div>
            </div>

            <div className="relative z-10 h-full flex flex-col justify-end p-8">
              <h1 className="text-5xl font-light text-white">Pricing plans</h1>
            </div>
          </div>

          {/* Pricing Cards Section */}
          <div className="mt-16">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mt-4 mb-4">
                Choose the plan that fits your needs
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
              <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-200 flex flex-col h-full">
                <div className="mb-6">
                  <h3 className="text-3xl font-bold text-gray-900 mb-2">
                    Basic
                  </h3>
                  <p className="text-gray-800 text-sm">
                    Great for private individuals
                  </p>
                </div>
                <div className="space-y-3 mb-8 flex-grow">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                    <span className="text-gray-700 whitespace-nowrap">
                      1 User
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                    <span className="text-gray-700 whitespace-nowrap">
                      Unlimited Projects
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                    <span className="text-gray-700 whitespace-nowrap">
                      Download prototypes
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                    <span className="text-gray-700 whitespace-nowrap">
                      1 Gb workspace
                    </span>
                  </div>
                </div>
                <div className="mb-6">
                  <span className="text-5xl font-bold text-gray-900">Free</span>
                </div>
                <button className="w-full py-3 px-6 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center space-x-2 border-2 border-gray-300 text-gray-700 hover:border-gray-400 hover:bg-gray-50">
                  <span>Get started</span>
                  <span className="text-3xl">›</span>
                </button>
              </div>

              {/* Premium Plan */}
              <div className="relative flex flex-col h-full">
                {/* Popular Badge */}
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                  <span className="bg-white text-purple-600 px-6 py-2 rounded-full text-sm font-medium border border-purple-200">
                    Popular
                  </span>
                </div>
                <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-3xl p-8 shadow-lg text-white flex flex-col h-full">
                  <div className="mb-6">
                    <h3 className="text-3xl font-bold mb-2">Premium</h3>
                    <p className="text-purple-100 text-sm">
                      14 days free period
                    </p>
                  </div>
                  <div className="space-y-3 mb-8 flex-grow">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-purple-300 rounded-full"></div>
                      <span className="text-purple-100 whitespace-nowrap">
                        3 Users
                      </span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-purple-300 rounded-full"></div>
                      <span className="text-purple-100 whitespace-nowrap">
                        Unlimited Projects
                      </span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-purple-300 rounded-full"></div>
                      <span className="text-purple-100 whitespace-nowrap">
                        Download prototypes
                      </span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-purple-300 rounded-full"></div>
                      <span className="text-purple-100 whitespace-nowrap">
                        100 Gb workspace
                      </span>
                    </div>
                  </div>
                  <div className="mb-6">
                    <div className="flex items-baseline">
                      <span className="text-5xl font-bold">$99</span>
                      <span className="text-purple-200 ml-1">/mo</span>
                    </div>
                  </div>
                  <button className="w-full py-3 px-6 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center space-x-2 bg-gray-800 text-white hover:bg-gray-900">
                    <span>Get started</span>
                    <span className="text-3xl">›</span>
                  </button>
                </div>
              </div>

              {/* Pro Plan */}
              <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-3xl p-8 shadow-lg text-white flex flex-col h-full">
                <div className="mb-6">
                  <h3 className="text-3xl font-bold mb-2">Pro</h3>
                  <p className="text-blue-100 text-sm">
                    Perfect for small teams
                  </p>
                </div>
                <div className="space-y-3 mb-8 flex-grow">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-blue-300 rounded-full"></div>
                    <span className="text-blue-100 whitespace-nowrap">
                      10 Users
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-blue-300 rounded-full"></div>
                    <span className="text-blue-100 whitespace-nowrap">
                      Unlimited Projects
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-blue-300 rounded-full"></div>
                    <span className="text-blue-100 whitespace-nowrap">
                      Download prototypes
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-blue-300 rounded-full"></div>
                    <span className="text-blue-100 whitespace-nowrap">
                      250 Gb workspace
                    </span>
                  </div>
                </div>
                <div className="mb-6">
                  <div className="flex items-baseline">
                    <span className="text-5xl font-bold">$149</span>
                    <span className="text-blue-200 ml-1">/mo</span>
                  </div>
                </div>
                <button className="w-full py-3 px-6 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center space-x-2 bg-blue-700 text-white hover:bg-blue-800">
                  <span>Get started</span>
                  <span className="text-3xl">›</span>
                </button>
              </div>

              {/* Unlimited Plan */}
              <div className="bg-gradient-to-br from-emerald-400 to-emerald-500 rounded-3xl p-8 shadow-lg text-white flex flex-col h-full">
                <div className="mb-6">
                  <h3 className="text-3xl font-bold mb-2">Unlimited</h3>
                  <p className="text-emerald-100 text-sm">
                    Great for teams and organizations
                  </p>
                </div>
                <div className="space-y-3 mb-8 flex-grow">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-emerald-300 rounded-full"></div>
                    <span className="text-emerald-100 whitespace-nowrap">
                      100 Users
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-emerald-300 rounded-full"></div>
                    <span className="text-emerald-100 whitespace-nowrap">
                      Unlimited Projects
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-emerald-300 rounded-full"></div>
                    <span className="text-emerald-100 whitespace-nowrap">
                      Download prototypes
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-emerald-300 rounded-full"></div>
                    <span className="text-emerald-100 whitespace-nowrap">
                      Unlimited workspace
                    </span>
                  </div>
                </div>
                <div className="mb-6">
                  <div className="flex items-baseline">
                    <span className="text-5xl font-bold">$199</span>
                    <span className="text-emerald-200 ml-1">/mo</span>
                  </div>
                </div>
                <button className="w-full py-3 px-6 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center space-x-2 bg-emerald-600 text-white hover:bg-emerald-700 border border-emerald-400">
                  <span>Get started</span>
                  <span className="text-3xl">›</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Section */}
        <section className="text-black py-16">
          <div className="container mx-auto px-16">
            <div className="flex flex-col lg:flex-row gap-16">
              {/* Left */}
              <div className="lg:w-1/2 space-y-8">
                <div className="text-sm text-gray-400 tracking-wide">
                  [ get in touch ]
                </div>
                <h2 className="text-4xl md:text-5xl font-bold leading-tight">
                  We are always ready to help you and answer your questions
                </h2>
                <p className="text-black">
                  Have questions or need assistance? Contact us anytime.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <h4 className="font-semibold text-lg">Phone</h4>
                    <p className="text-gray-800">+91-05124050467</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">Our Location</h4>
                    <p className="text-gray-800">
                      Lucknow, Uttar Pradesh, India
                    </p>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold text-lg">Email</h4>
                  <div className="bg-white text-black px-4 py-2 rounded-xl inline-block">
                    Contact@bharatai.bsearch.in
                  </div>
                </div>
              </div>

              {/* Right - Contact Form */}
              <div className="lg:w-1/2">
                <div className="bg-white rounded-3xl p-8 text-gray-900 shadow-lg">
                  <h3 className="text-2xl font-bold mb-6 text-gray-800">
                    Get in Touch
                  </h3>
                  <form className="space-y-6">
                    <input
                      type="text"
                      placeholder="Full name"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                    <input
                      type="email"
                      placeholder="Email"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                    <input
                      type="text"
                      placeholder="Subject"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                    <textarea
                      placeholder="Message"
                      rows="4"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 resize-none"
                    ></textarea>
                    <button
                      type="submit"
                      className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-medium flex items-center gap-2"
                    >
                      Send message <ChevronRight className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default PricingPage;
