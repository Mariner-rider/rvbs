import React, { useState, useRef, useEffect } from "react";
import { MessageCircle, Camera, Sparkles } from "lucide-react";

import ChatHeader from "./ChatHeader";
import ChatHistoryModal from "./ChatHistoryModal";
import ChatInput from "./ChatInput";
import ChatResponse from "./ChatResponse";
import ProfileMenu from "./ProfileMenu";
import SearchModal from "./SearchModal";

const ChatInterface = () => {
  const [message, setMessage] = useState("");
  const [selectedMode, setSelectedMode] = useState("Chat");
  const [showHistoryCard, setShowHistoryCard] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [theme, setTheme] = useState("light");
  const [isThinking, setIsThinking] = useState(false);
  const [isGeneratingReasoning, setIsGeneratingReasoning] = useState(false);
  const [simulatedReasoningLines, setSimulatedReasoningLines] = useState([]);
  const [isTypingAiResponse, setIsTypingAiResponse] = useState(false);
  const [currentAiTypingText, setCurrentAiTypingText] = useState("");
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [archivedChats, setArchivedChats] = useState([]);
  const [messages, setMessages] = useState([]);
  const [chatHistory, setChatHistory] = useState([]);
  const [currentChatId, setCurrentChatId] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  // ADD THIS NEW STATE FOR SHARE MODAL
  const [showShareModal, setShowShareModal] = useState(false);

  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const messagesEndRef = useRef(null);

  const addMessage = (msg) => setMessages((prev) => [...prev, msg]);

  const isAuthenticated = false;
  const user = null;

  const modes = [
    { name: "Chat", icon: MessageCircle },
    { name: "Image", icon: Camera },
    { name: "Extreme", icon: Sparkles },
  ];

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [
    messages,
    currentAiTypingText,
    isGeneratingReasoning,
    isTypingAiResponse,
  ]);

  // Enhanced chat saving logic
  useEffect(() => {
    if (messages.length > 0) {
      const firstUserMessage = messages.find((msg) => msg.sender === "user");
      if (firstUserMessage) {
        const chatTitle =
          firstUserMessage.text.length > 50
            ? firstUserMessage.text.substring(0, 50) + "..."
            : firstUserMessage.text;

        if (currentChatId) {
          // Update existing chat
          setChatHistory((prev) =>
            prev.map((chat) =>
              chat.id === currentChatId
                ? { ...chat, messages, timestamp: new Date().toISOString() }
                : chat
            )
          );
        } else {
          // Create new chat
          const newChatId = Date.now().toString();
          const newChat = {
            id: newChatId,
            title: chatTitle,
            timestamp: new Date().toISOString(),
            messages: messages,
          };
          setChatHistory((prev) => [newChat, ...prev]);
          setCurrentChatId(newChatId);
        }
      }
    }
  }, [messages, currentChatId]);

  const typeAiResponseWordByWord = (fullText, messageId) => {
    const words = fullText.split(" ");
    let typedText = "";
    let i = 0;

    setIsTypingAiResponse(true);
    setCurrentAiTypingText("");

    const interval = setInterval(() => {
      if (i < words.length) {
        typedText += (i > 0 ? " " : "") + words[i];
        setCurrentAiTypingText(typedText);
        setMessages((prevMessages) =>
          prevMessages.map((msg) =>
            msg.id === messageId ? { ...msg, text: typedText } : msg
          )
        );
        i++;
      } else {
        clearInterval(interval);
        setIsTypingAiResponse(false);
        setCurrentAiTypingText("");
        setMessages((prevMessages) =>
          prevMessages.map((msg) =>
            msg.id === messageId ? { ...msg, text: fullText } : msg
          )
        );
      }
    }, 80);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (message.trim()) {
      const userMessage = {
        id: Date.now(),
        text: message,
        sender: "user",
        timestamp: new Date(),
      };

      addMessage(userMessage);
      setMessage("");

      setIsThinking(true);
      setIsGeneratingReasoning(true);

      const tempReasoningLines = [
        "• Analyzing the user's query for keywords.",
        "• Identifying the core intent of the question.",
        "• Retrieving relevant information from knowledge base.",
        "• Structuring the response for clarity and completeness.",
        "• Formatting the answer based on identified intent.",
      ];
      setSimulatedReasoningLines(tempReasoningLines);

      const reasoningDuration = tempReasoningLines.length * (60 + 800) + 500;

      setTimeout(() => {
        setIsGeneratingReasoning(false);
        const pauseAfterReasoning = 1000;

        setTimeout(() => {
          const aiResponsePlaceholder = {
            id: Date.now() + 1,
            text: "",
            sender: "ai",
            timestamp: new Date(),
            isTyping: true,
          };
          addMessage(aiResponsePlaceholder);

          const fullAiResponseText =
            "I'm here to help you with your questions! This is a longer response to test the scrolling functionality. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris. This response is generated after I've thoroughly thought through your request.";

          typeAiResponseWordByWord(
            fullAiResponseText,
            aiResponsePlaceholder.id
          );
          setIsThinking(false);
        }, pauseAfterReasoning);
      }, reasoningDuration);
    }
  };

  const handleRestoreChat = (chatId) => {
    const chatToRestore = archivedChats.find((chat) => chat.id === chatId);
    if (chatToRestore) {
      // Remove archivedAt timestamp and add back to active chats
      const { archivedAt, ...restoredChat } = chatToRestore;
      setChatHistory((prev) => [restoredChat, ...prev]);

      // Remove from archived chats
      setArchivedChats((prev) => prev.filter((chat) => chat.id !== chatId));
    }
  };

  const handleDeleteArchivedChat = (chatId) => {
    setArchivedChats((prev) => prev.filter((chat) => chat.id !== chatId));
  };

  const handleSelectChat = (chat) => {
    setMessages(chat.messages || []);
    setCurrentChatId(chat.id);
    setShowHistoryCard(false);
  };

  const startNewChat = () => {
    setMessages([]);
    setCurrentChatId(null);
    setShowHistoryCard(false);
  };

  const handleDeleteChat = (chatId) => {
    setChatHistory((prev) => prev.filter((chat) => chat.id !== chatId));
    setArchivedChats((prev) => prev.filter((chat) => chat.id !== chatId));
    if (currentChatId === chatId) {
      setCurrentChatId(null);
      setMessages([]);
    }
    console.log("Deleted chat:", chatId);
  };

  // FIXED: Complete archive chat functionality
  const handleArchiveChat = (chatId) => {
    const chatToArchive = chatHistory.find((chat) => chat.id === chatId);
    if (chatToArchive) {
      // Create archived chat with timestamp
      const archivedChat = {
        ...chatToArchive,
        archivedAt: new Date().toISOString(),
      };

      // Remove from active chats
      setChatHistory((prev) => prev.filter((chat) => chat.id !== chatId));

      // Add to archived chats
      setArchivedChats((prev) => [...prev, archivedChat]);

      // If this was the current chat, clear it
      if (currentChatId === chatId) {
        setCurrentChatId(null);
        setMessages([]);
      }

      console.log("Archived chat:", chatId);
    }
  };

  const handleOpenArchivedChats = () => {
    // This should open the Settings modal with archived chats section
    setShowSettings(true);
    // You might need additional state to navigate to archived section
  };

  // ADD THIS FUNCTION TO HANDLE SHARE MODAL STATE
  const handleShareModalOpen = () => {
    setShowShareModal(true);
  };

  const handleShareModalClose = () => {
    setShowShareModal(false);
  };

  const handleShareChat = (chatId) => {
    const chat =
      chatHistory.find((c) => c.id === chatId) ||
      archivedChats.find((c) => c.id === chatId);
    if (chat) {
      console.log("Sharing chat:", chat.title);
      // You can add more share logic here
    }
  };

  const handleRenameChat = (chatId, newTitle) => {
    setChatHistory((prev) =>
      prev.map((chat) =>
        chat.id === chatId ? { ...chat, title: newTitle } : chat
      )
    );
    console.log("Rename chat:", chatId, newTitle);
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, {
          type: "audio/webm",
        });
        const audioUrl = URL.createObjectURL(audioBlob);
        console.log("Recorded audio URL:", audioUrl);
        setIsRecording(false);
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Microphone access denied or error:", err);
      setIsRecording(false);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
    }
  };

  const handleThemeChange = (newTheme) => {
    setTheme(newTheme);
  };

  const handleCookieSettingsClick = () => {
    // You can implement cookie settings functionality here
    console.log("Cookie settings clicked");
    // For example, open a modal or navigate to cookie settings page
  };

  const isDark =
    theme === "dark" ||
    (theme === "system" &&
      window.matchMedia("(prefers-color-scheme: dark)").matches);

  const isInitialState = messages.length === 0;

  // Check if any modal is open to determine blur state
  const isAnyModalOpen = showSearchModal || showShareModal;

  // Disclaimer component
  const DisclaimerText = () => (
    <div className="text-center mt-3 px-4">
      <p className={`text-xs ${isDark ? "text-gray-400" : "text-gray-500"}`}>
        BharatAi may not always be accurate. Always verify crucial details.{" "}
        <button
          onClick={handleCookieSettingsClick}
          className={`underline hover:no-underline transition-all duration-200 ${
            isDark ? "text-gray-400 hover:text-gray-300" : "text-gray-500 hover:text-gray-400"
          }`}
        >
          Review your cookie settings
        </button>
        .
      </p>
    </div>
  );

  return (
    <div
      className={`min-h-screen ${
        isDark
          ? "bg-black text-white"
          : "text-black bg-[radial-gradient(circle_at_center,transparent_0%,transparent_30%,rgba(255,255,255,0.6)_70%,rgba(255,255,255,0.6)_100%),linear-gradient(to_right,#e2eef6_0%,#d3def8_45%,#c8d3f8_65%,#dcd6f7_85%,#f1eef6_100%)]"
      } flex flex-col`}
    >
      <style jsx>{`
        .scrollbar-custom::-webkit-scrollbar {
          width: 8px;
        }
        .scrollbar-custom::-webkit-scrollbar-track {
          background: ${isDark ? "#1e1e1e" : "#f9fafb"};
          border-radius: 4px;
        }
        .scrollbar-custom::-webkit-scrollbar-thumb {
          background: ${isDark ? "#374151" : "#9ca3af"};
          border-radius: 4px;
        }
        .scrollbar-custom::-webkit-scrollbar-thumb:hover {
          background: ${isDark ? "#4b5563" : "#6b7280"};
        }
      `}</style>
      <div className="fixed top-0 left-0 w-full z-10">
        <ChatHeader
          isDark={isDark}
          onHistoryClick={() => setShowHistoryCard(true)}
          onProfileClick={() => setShowProfileMenu(!showProfileMenu)}
          selectedChatId={currentChatId}
          chatHistory={chatHistory}
          onShareChat={handleShareChat}
          // PASS THE SHARE MODAL HANDLERS
          onShareModalOpen={handleShareModalOpen}
          onShareModalClose={handleShareModalClose}
          showShareModal={showShareModal}
        />
      </div>
      <main className="flex-1 flex flex-col items-center justify-center min-h-screen px-4 overflow-hidden pt-0">
        <div className="w-full max-w-2xl flex flex-col h-full">
          {isInitialState && (
            <div className="flex flex-col items-center justify-center space-y-8 h-full">
              <h1
                className={`text-4xl font-light ${
                  isDark ? "text-white" : "text-black"
                } tracking-wide`}
              >
                BharatAI
              </h1>
              <div className="w-full">
                <ChatInput
                  message={message}
                  setMessage={setMessage}
                  handleSubmit={handleSubmit}
                  modes={modes}
                  selectedMode={selectedMode}
                  setSelectedMode={setSelectedMode}
                  isRecording={isRecording}
                  startRecording={startRecording}
                  stopRecording={stopRecording}
                  isDark={isDark}
                  isInitialState={isInitialState}
                  isBlurred={isAnyModalOpen} // PASS BLUR STATE
                />
                {/* Disclaimer positioned directly below ChatInput */}
                <DisclaimerText />
              </div>
            </div>
          )}

          {!isInitialState && (
            <>
              <div className="flex-1 overflow-y-auto scrollbar-custom pb-40 pt-4">
                <ChatResponse
                  messages={messages}
                  isThinking={isThinking}
                  isDark={isDark}
                  reasoningLines={simulatedReasoningLines}
                  isGeneratingReasoning={isGeneratingReasoning}
                  isTypingAiResponse={isTypingAiResponse}
                />
                <div ref={messagesEndRef} />
              </div>

              <div
                className={`fixed bottom-0 left-0 w-full ${
                  // LOWER Z-INDEX WHEN MODAL IS OPEN
                  isAnyModalOpen ? "z-0" : "z-10"
                }`}
                style={{
                  background: isDark ? "#000" : "transparent",
                }}
              >
                <div className="max-w-2xl mx-auto px-4 pb-4">
                  <ChatInput
                    message={message}
                    setMessage={setMessage}
                    handleSubmit={handleSubmit}
                    modes={modes}
                    selectedMode={selectedMode}
                    setSelectedMode={setSelectedMode}
                    isRecording={isRecording}
                    startRecording={startRecording}
                    stopRecording={stopRecording}
                    isDark={isDark}
                    isInitialState={isInitialState}
                    isBlurred={isAnyModalOpen} // PASS BLUR STATE
                  />
                  {/* Disclaimer positioned directly below ChatInput */}
                  <DisclaimerText />
                </div>
              </div>
            </>
          )}
        </div>
      </main>

      {showProfileMenu && (
        <ProfileMenu
          isDark={isDark}
          theme={theme}
          onThemeChange={handleThemeChange}
          onClose={() => setShowProfileMenu(false)}
          user={user}
          isAuthenticated={isAuthenticated}
          archivedChats={archivedChats}
          onRestoreChat={handleRestoreChat}
          onDeleteArchivedChat={handleDeleteArchivedChat}
          onSelectArchivedChat={handleSelectChat}
        />
      )}

      {showHistoryCard && (
        <>
          <ChatHistoryModal
            isDark={isDark}
            isOpen={showHistoryCard}
            onClose={() => setShowHistoryCard(false)}
            chatHistory={chatHistory}
            onSelectChat={handleSelectChat}
            onNewChat={startNewChat}
            onDeleteChat={handleDeleteChat}
            onShareChat={handleShareChat}
            onArchiveChat={handleArchiveChat}
            onRenameChat={handleRenameChat}
            selectedChatId={currentChatId}
            onOpenSearch={() => setShowSearchModal(true)}
            onOpenArchivedChats={handleOpenArchivedChats}
          />

          <SearchModal
            isOpen={showSearchModal}
            onClose={() => setShowSearchModal(false)}
            isDark={isDark}
            chatHistory={chatHistory}
            onSelectChat={handleSelectChat}
            onDeleteChat={handleDeleteChat}
            onRenameChat={handleRenameChat}
          />
        </>
      )}
    </div>
  );
};

export default ChatInterface;