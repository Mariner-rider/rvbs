import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import PricingPage from "../pricing";
import Settings from "./Settings"; // Adjust path as needed
import About from "../About";
import {
  Sun,
  Moon,
  Info,
  FileText,
  Shield,
  Github,
  Instagram,
  ExternalLink,
  Settings as SettingsIcon, // ✅ Renamed to avoid conflict
  LogOut,
  Zap,
  Twitter,
  Triangle,
  Bug,
} from "lucide-react";
import { Link } from "react-router-dom";

const ProfileMenu = ({
  isDark,
  theme,
  onThemeChange,
  onClose,
  user,
  isAuthenticated,
  // ADD THESE:
  archivedChats,
  onRestoreChat,
  onDeleteArchivedChat,
  onSelectArchivedChat,
}) => {
  const navigate = useNavigate();
  const [showSettings, setShowSettings] = useState(false);
  const themeOptions = [
    { name: "Light", icon: Sun, value: "light" },
    { name: "Dark", icon: Moon, value: "dark" },
  ];

  const MenuItem = ({
    icon: Icon,
    text,
    subtext,
    onClick,
    hasArrow = false,
    isDark,
  }) => (
    <button
      className={`w-full text-left px-2 py-1 transition-colors rounded mb-1 ${
        isDark
          ? "hover:bg-[#2c2c2c] text-white"
          : "hover:bg-gray-100 text-black"
      }`}
      onClick={onClick}
    >
      <div className="flex space-x-3 items-start">
        <div className="pt-0.5">
          <Icon
            size={16}
            className={isDark ? "text-gray-400" : "text-gray-600"}
          />
        </div>
        <div className="flex flex-col leading-tight">
          <span className="text-sm">{text}</span>
          {subtext && (
            <span
              className={`text-[10px] leading-none ${
                isDark ? "text-gray-400" : "text-gray-600"
              }`}
            >
              {subtext}
            </span>
          )}
        </div>
      </div>
    </button>
  );

  return (
    <div className="fixed inset-0 z-40" onClick={onClose}>
      <div
        className="absolute top-14 right-4 z-50"
        onClick={(e) => e.stopPropagation()}
      >
        <div
          className={`${
            isDark ? "bg-[#1a1a1a]" : "bg-white"
          } rounded-lg shadow-lg border ${
            isDark ? "border-gray-700" : "border-gray-200"
          } w-64 py-1 px-2`}
        >
          {/* User Section */}
          <div
            className={`px-2 py-2 border-b ${
              isDark ? "border-gray-700" : "border-gray-200"
            }`}
          >
            <div className="flex items-center space-x-2">
              <div
                className={`${
                  isDark ? "bg-blue-600" : "bg-blue-600"
                } rounded-full w-7 h-7 flex items-center justify-center`}
              >
                <span className="text-white font-medium text-sm">G</span>
              </div>
              <div>
                <div
                  className={`font-medium text-sm ${
                    isDark ? "text-white" : "text-black"
                  }`}
                >
                  Guest
                </div>
                <div
                  className={`text-xs ${
                    isDark ? "text-gray-400" : "text-gray-600"
                  } flex items-center space-x-1`}
                >
                  <span>guest@email.com</span>
                  <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                </div>
              </div>
            </div>
          </div>

          {/* Upgrade Section */}
          <div className="py-1">
            <MenuItem
              icon={Zap}
              text="Upgrade to Pro"
              subtext="Unlimited searches & premium models"
              onClick={() => navigate("/test/pricing")}
              isDark={isDark}
            />
          </div>

          {/* Settings */}
          <div
            className={`border-t ${
              isDark ? "border-gray-700" : "border-gray-200"
            } pt-1 pb-0`}
          >
            <MenuItem
              icon={SettingsIcon}
              text="Settings"
              onClick={() => setShowSettings(true)}
              isDark={isDark}
            />
          </div>

          {/* Theme Section */}
          <div className="px-2 py-2">
            <div className="flex items-center justify-between">
              <div
                className={`flex items-center space-x-2 text-sm font-medium ${
                  isDark ? "text-white" : "text-black"
                }`}
              >
                <Sun size={16} />
                <span>Theme</span>
              </div>
              <div className="flex items-center space-x-1">
                {themeOptions.map((option) => {
                  const IconComponent = option.icon;
                  return (
                    <button
                      key={option.value}
                      onClick={() => onThemeChange(option.value)}
                      className={`p-1 rounded transition-colors ${
                        theme === option.value
                          ? isDark
                            ? "bg-gray-600 text-white"
                            : "bg-gray-200 text-black"
                          : isDark
                          ? "text-gray-400 hover:text-white hover:bg-[#2c2c2c]"
                          : "text-gray-600 hover:text-black hover:bg-gray-100"
                      }`}
                    >
                      <IconComponent size={14} />
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <div
            className={`border-t ${
              isDark ? "border-gray-700" : "border-gray-200"
            } py-1`}
          >
            <Link to="/test/about">
              <MenuItem icon={Info} text="About" isDark={isDark} />
            </Link>

            <Link to="/test/terms">
              <MenuItem icon={FileText} text="Terms" isDark={isDark} />
            </Link>

            <Link to="/test/privacy">
              <MenuItem icon={Shield} text="Privacy" isDark={isDark} />
            </Link>

            {/* Divider after Privacy */}
            <div
              className={`my-1 border-t ${
                isDark ? "border-gray-700" : "border-gray-200"
              }`}
            />

            <MenuItem icon={Github} text="Github" isDark={isDark} />
            <MenuItem icon={Twitter} text="X.com" isDark={isDark} />
            <MenuItem icon={Instagram} text="Instagram" isDark={isDark} />
            <MenuItem
              icon={Triangle}
              text="Deploy with Vercel"
              isDark={isDark}
            />
            <MenuItem icon={Bug} text="Feature/Bug Request" isDark={isDark} />
          </div>

          {/* Sign Out Button */}
          <div
            className={`px-2 py-2 border-t ${
              isDark ? "border-gray-700" : "border-gray-200"
            }`}
          >
            <button
              className={`flex items-center justify-between w-full text-left py-1 px-2 rounded transition-colors ${
                isDark
                  ? "hover:bg-[#2c2c2c] text-white"
                  : "hover:bg-gray-100 text-black"
              }`}
              onClick={() => {
                console.log("Sign out clicked");
              }}
            >
              <div className="flex items-center space-x-2">
                <LogOut
                  size={16}
                  className={isDark ? "text-gray-400" : "text-gray-600"}
                />
                <span className="text-sm">Sign Out</span>
              </div>
              <ExternalLink
                size={12}
                className={isDark ? "text-gray-400" : "text-gray-600"}
              />
            </button>
          </div>
        </div>
      </div>
      {showSettings && (
        <Settings
          isDark={isDark}
          onClose={onClose}
          user={user}
          // ADD THESE:
          archivedChats={archivedChats}
          onRestoreChat={onRestoreChat}
          onDeleteArchivedChat={onDeleteArchivedChat}
          onSelectArchivedChat={onSelectArchivedChat}
        />
      )}
    </div>
  );
};

export default ProfileMenu;
