import React, { useRef, useState, useEffect } from "react";
import {
  Mic,
  ArrowUp,
  Paperclip,
  Globe,
  MessageSquare,
  TrendingUp,
  BookOpen,
  DollarSign,
  Video,
  Zap,
  Check,
} from "lucide-react";

const ChatInput = ({
  message = "",
  setMessage = () => {},
  handleSubmit = () => {},
  isRecording = false,
  startRecording = () => {},
  stopRecording = () => {},
  isDark = false,
  isInitialState = true,
  isBlurred = false,
}) => {
  const textareaRef = useRef(null);
  const searchInputRef = useRef(null);
  const fileInputRef = useRef(null);
  const dropdownRef = useRef(null);
  const modeButtonRef = useRef(null);

  const [selectedSearchMode, setSelectedSearchMode] = useState("Chat");
  const [showModes, setShowModes] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [extremeMode, setExtremeMode] = useState(false);
  const [dropdownAbove, setDropdownAbove] = useState(false);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target) &&
        !modeButtonRef.current.contains(event.target)
      ) {
        setShowModes(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Focus search bar when dropdown opens
  useEffect(() => {
    if (showModes && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [showModes]);

  // Decide dropdown position (above or below)
  useEffect(() => {
    if (showModes && modeButtonRef.current) {
      const rect = modeButtonRef.current.getBoundingClientRect();
      const spaceBelow = window.innerHeight - rect.bottom;
      const spaceAbove = rect.top;
      setDropdownAbove(spaceBelow < 200 && spaceAbove > spaceBelow);
    }
  }, [showModes, message]);

  const searchModes = [
    { 
      name: "Web", 
      icon: Globe,
      description: "Search across the entire Internet powered by Exa AI"
    },
    { 
      name: "X", 
      icon: () => <span className="font-bold text-xs">𝕏</span>,
      description: "Search X posts"
    },
    { 
      name: "Stocks", 
      icon: TrendingUp,
      description: "Stock and currency information"
    },
    { 
      name: "Reddit", 
      icon: () => <span className="font-bold text-orange-500 text-xs">R</span>,
      description: "Search Reddit posts"
    },
    { 
      name: "Academic", 
      icon: BookOpen,
      description: "Search academic papers powered by Exa"
    },
    { 
      name: "Chat", 
      icon: MessageSquare,
      description: "Talk to the model directly."
    },
    { 
      name: "Crypto", 
      icon: DollarSign,
      description: "Cryptocurrency research powered by CoinGecko"
    },
    { 
      name: "YouTube", 
      icon: Video,
      description: "Search YouTube videos powered by Exa"
    },
  ];

  const filteredModes = searchModes.filter((mode) =>
    mode.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleTextareaChange = (e) => {
    setMessage(e.target.value);
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = "auto";
      textarea.style.height = Math.min(textarea.scrollHeight, 200) + "px";
    }
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      console.log("Selected file:", file);
    }
  };

  const placeholder = `Search ${selectedSearchMode.toLowerCase()}...`;

  const containerClass = `relative w-full ${
    isDark ? "bg-[#1e1e1e] border-gray-600" : "bg-gray-50 border-gray-300"
  } rounded-2xl border transition-colors ${
    isBlurred ? "blur-sm pointer-events-none" : ""
  }`;

  const textareaClass = `w-full bg-transparent ${
    isDark
      ? "text-white placeholder-gray-400"
      : "text-black placeholder-gray-500"
  } pl-4 pt-4 pb-16 pr-4 text-lg rounded-2xl focus:outline-none resize-none overflow-y-auto min-h-[60px] max-h-[200px] searchbar-textarea`;

  return (
    <div className="w-full">
      <div className={containerClass}>
        {/* Textarea */}
        <textarea
          ref={textareaRef}
          value={message}
          onChange={handleTextareaChange}
          placeholder={placeholder}
          className={textareaClass}
          onKeyPress={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSubmit(e);
            }
          }}
          disabled={isBlurred}
        />

        {/* Bottom bar */}
        <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between space-x-2">
          <div className="flex items-center space-x-2">
            {/* Mode Dropdown */}
            <div className="relative group" ref={dropdownRef}>
              <button
                ref={modeButtonRef}
                type="button"
                onClick={() => setShowModes((prev) => !prev)}
                className={`flex items-center justify-between px-3 h-9 rounded-full shadow-sm transition ${
                  isDark
                    ? "bg-[#2c2c2c] hover:bg-[#3a3a3a] text-gray-200"
                    : "bg-gray-100 hover:bg-gray-200 text-gray-700"
                }`}
              >
                {/* Left: current mode icon */}
                <div className="flex items-center space-x-1">
                  {(() => {
                    const selected = searchModes.find(
                      (m) => m.name === selectedSearchMode
                    );
                    const Icon = selected?.icon;
                    return Icon && <Icon size={14} />;
                  })()}
                </div>

                {/* Right: SVG up/down arrows */}
                <div className="ml-2 flex flex-col items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-2 w-3"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M5 15l7-7 7 7"
                    />
                  </svg>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-2 w-3"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </div>
              </button>

              {/* Tooltip */}
              <div className="absolute -top-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition bg-gray-800 text-white text-xs px-3 py-1 rounded-lg whitespace-nowrap">
                Choose search mode
              </div>

              {showModes && (
                <div
                  className={`absolute z-50 mt-1 rounded-2xl shadow-lg w-64 overflow-hidden border ${
                    isDark 
                      ? "bg-gray-900 border-gray-700" 
                      : "bg-white border-gray-200"
                  }`}
                  style={{
                    top: dropdownAbove ? "auto" : "100%",
                    bottom: dropdownAbove ? "100%" : "auto",
                    marginTop: dropdownAbove ? "0" : "5px",
                    marginBottom: dropdownAbove ? "5px" : "0",
                  }}
                >
                  {/* Header */}
                  <div className={`px-3 py-2 border-b ${
                    isDark ? "border-gray-700" : "border-gray-200"
                  }`}>
                    <div className="relative">
                      {/* Search icon (left) */}
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        className={`absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 ${
                          isDark ? "text-gray-400" : "text-gray-500"
                        }`}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M21 21l-4.35-4.35M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z"
                        />
                      </svg>

                      {/* Input */}
                      <input
                        ref={searchInputRef}
                        type="text"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Search modes..."
                        className={`w-full pl-10 pr-3 py-2 rounded-md text-xs  ${
                          isDark
                            ? " text-gray-200 placeholder-gray-400 "
                            : "  text-gray-800 placeholder-gray-500 "
                        }`}
                      />
                    </div>
                  </div>

                 

                  {/* Options */}
                  <div className="max-h-60 overflow-y-auto hide-scrollbar">
                     {/* Section Header */}
                    <h3 className={`text-xs font-medium px-3 py-2 ${
                      isDark ? "text-gray-300" : "text-gray-600"
                    }`}>
                      Search Mode
                    </h3>
                  
                    {filteredModes.map((mode) => {
                      const Icon = mode.icon;
                      const isSelected = selectedSearchMode === mode.name;
                      return (
                        <button
                          key={mode.name}
                          type="button"
                          onClick={() => {
                            setSelectedSearchMode(mode.name);
                            setShowModes(false);
                            setSearchTerm("");
                          }}
                          className={`flex items-start space-x-3 w-full px-3 py-3 text-left transition-colors rounded-3xl ${
                            isDark
                              ? "hover:bg-gray-800 text-gray-200"
                              : "hover:bg-gray-100 text-gray-700"
                          } 
                          }`}
                        >
                          {/* Icon */}
                          <div className="flex-shrink-0 mt-0.5">
                            {Icon && <Icon size={18} />}
                          </div>
                          
                          {/* Content */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <div className="font-medium text-xs">
                                {mode.name}
                              </div>
                              {isSelected && (
                                <Check size={16} className="text-blue-500 flex-shrink-0" />
                              )}
                            </div>
                            <div className={`text-xs mt-0.5 ${
                              isDark ? "text-gray-400" : "text-gray-500"
                            }`}>
                              {mode.description}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Extreme Search */}
            <div className="relative group">
              <button
                type="button"
                onClick={() => setExtremeMode((prev) => !prev)}
                className={`flex items-center justify-center w-9 h-9 rounded-full shadow-sm transition ${
                  extremeMode
                    ? "bg-gray-300 text-gray-700"
                    : isDark
                    ? "bg-[#2c2c2c] hover:bg-[#3a3a3a] text-gray-200"
                    : "bg-gray-100 hover:bg-gray-200 text-gray-700"
                }`}
              >
                <Zap size={16} />
              </button>
              {/* Tooltip */}
              <div className="absolute -top-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition bg-gray-800 text-white text-xs px-3 py-1 rounded-lg whitespace-nowrap">
                {extremeMode
                  ? "Extreme Search Mode On"
                  : "Switch to Extreme Search Mode"}
              </div>
            </div>
          </div>

          {/* Mic / Send + Attachment */}
          <div className="flex items-center space-x-2">
            <input
              type="file"
              accept="image/*,.pdf,.doc,.docx"
              ref={fileInputRef}
              className="hidden"
              onChange={handleFileSelect}
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isBlurred}
              className={`p-2 rounded-full ${
                isDark
                  ? "bg-gray-800 text-gray-300 hover:bg-gray-700"
                  : "bg-gray-200 text-gray-600 hover:bg-gray-300"
              }`}
            >
              <Paperclip size={16} />
            </button>

            {message.trim() === "" ? (
              <button
                type="button"
                onClick={isRecording ? stopRecording : startRecording}
                disabled={isBlurred}
                className={`p-2 rounded-full ${
                  isDark
                    ? "bg-gray-700 hover:bg-gray-600"
                    : "bg-gray-200 hover:bg-gray-300"
                }`}
              >
                <Mic
                  size={18}
                  className={
                    isRecording
                      ? "text-red-500 animate-pulse"
                      : isDark
                      ? "text-white"
                      : "text-black"
                  }
                />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmit}
                disabled={isBlurred}
                className={`p-2 rounded-full ${
                  isDark
                    ? "bg-gray-700 hover:bg-gray-600"
                    : "bg-gray-200 hover:bg-gray-300"
                }`}
              >
                <ArrowUp
                  size={18}
                  className={isDark ? "text-white" : "text-black"}
                />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Transparent scrollbar styles */}
      <style jsx>{`
        .hide-scrollbar {
          scrollbar-width: none; /* Firefox */
          -ms-overflow-style: none; /* IE 10+ */
        }
        .hide-scrollbar::-webkit-scrollbar {
          display: none; /* Chrome/Safari */
        }
      `}</style>
    </div>
  );
};

export default ChatInput;