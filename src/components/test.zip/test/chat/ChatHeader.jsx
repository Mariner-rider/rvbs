import React, { useState } from "react";
import {
  Menu,
  User,
  Share,
  Zap,
  Facebook,
  MessageCircle,
  Copy,
  Check,
  X as CloseIcon,
  ExternalLink,
  Linkedin,
  Lock,
  Archive,
  Mail,        // Added missing import
  Twitter,     // Added missing import
  Send,
  MessageSquare         // Added missing import for Telegram
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import bharatAi from "/src/assets/images/bharatai2.png";

const ChatHeader = ({
  isDark,
  onHistoryClick,
  onProfileClick,
  selectedChatId,
  chatHistory = [],
  onShareChat,
  onShareModalOpen,
  onShareModalClose,
  showShareModal,
}) => {
  const [copySuccess, setCopySuccess] = useState(false);
  const navigate = useNavigate();

  const handleShareClick = () => {
    onShareModalOpen(); 
  };

  const handleSharePlatform = (platform) => {
    if (!selectedChatId) return;

    const chat = chatHistory.find((c) => c.id === selectedChatId);
    if (!chat) return;

    const shareText = `Check out this chat: ${chat.title}`;
    const shareUrl = `${window.location.origin}/chat/${selectedChatId}`;

    switch (platform) {
      case "facebook":
        window.open(
          `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
            shareUrl
          )}&quote=${encodeURIComponent(shareText)}`,
          "_blank"
        );
        break;
      case "whatsapp":
        window.open(
          `https://wa.me/?text=${encodeURIComponent(
            `${shareText} ${shareUrl}`
          )}`,
          "_blank"
        );
        break;
      case "linkedin":
        window.open(
          `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(
            shareUrl
          )}`,
          "_blank"
        );
        break;
      case "twitter":
        window.open(
          `https://twitter.com/intent/tweet?text=${encodeURIComponent(
            shareText
          )}&url=${encodeURIComponent(shareUrl)}`,
          "_blank"
        );
        break;
      case "reddit":
        window.open(
          `https://www.reddit.com/submit?url=${encodeURIComponent(
            shareUrl
          )}&title=${encodeURIComponent(shareText)}`,
          "_blank"
        );
        break;
      case "mail":        // Added missing mail handler
        window.open(
          `mailto:?subject=${encodeURIComponent(
            "Check out this chat"
          )}&body=${encodeURIComponent(`${shareText} ${shareUrl}`)}`,
          "_self"
        );
        break;
      case "telegram":    // Added missing telegram handler
        window.open(
          `https://t.me/share/url?url=${encodeURIComponent(
            shareUrl
          )}&text=${encodeURIComponent(shareText)}`,
          "_blank"
        );
        break;
      case "copy":
        navigator.clipboard.writeText(shareUrl).then(() => {
          setCopySuccess(true);
          setTimeout(() => setCopySuccess(false), 2000);
        });
        break;
    }
  };

  const handleArchive = () => {
    console.log("Archived chat:", selectedChatId);
    onShareModalClose(); 
  };

  const getShareUrl = () => {
    if (!selectedChatId) return "";
    return `${window.location.origin}/chat/${selectedChatId}`;
  };

  return (
    <>
      <header
        className={`flex justify-between items-center p-2 sm:p-3 md:p-4 ${
          isDark ? "" : ""
        }`}
        style={{
          background: isDark 
            ? "transparent" 
            : "transparent"
        }}
      >
        <div className="flex items-center gap-1.5 sm:gap-2 md:gap-3 lg:gap-4">
          <button
            className={`p-1.5 sm:p-2 rounded-lg transition-colors ${
              isDark ? "hover:bg-gray-800" : "hover:bg-gray-100"
            }`}
            onClick={onHistoryClick}
          >
            <Menu size={18} className="sm:w-5 sm:h-5" />
          </button>
          <img
            src={bharatAi}
            alt="Bharat AI"
            className="h-8 sm:h-9 md:h-10 w-auto"
          />
        </div>

        <div className="flex items-center gap-1 sm:gap-2">
          {selectedChatId && (
            <button
              className={`flex items-center gap-1 sm:gap-2 px-2 sm:px-3 py-1 sm:py-1.5 text-xs sm:text-sm border ${
                isDark
                  ? "border-gray-600 hover:bg-gray-700 text-white"
                  : "border-gray-300 hover:bg-gray-100 text-gray-700"
              } rounded-lg transition-colors`}
              onClick={handleShareClick}
            >
              <Share size={14} className="sm:w-4 sm:h-4" />
              <span>Share</span>
            </button>
          )}

          <button
            onClick={() => navigate("/test/pricing")}
            className={`flex items-center gap-1 sm:gap-2 px-2 sm:px-3 py-1 sm:py-1.5 text-xs sm:text-sm border ${
              isDark
                ? "border-gray-600 hover:bg-gray-700 text-white"
                : "border-gray-300 hover:bg-gray-100 text-gray-700"
            } rounded-lg transition-colors`}
          >
            <Zap size={14} className="sm:w-4 sm:h-4" />
            <span>Upgrade</span>
          </button>

          <div className="relative">
            <button
              className={`p-1.5 sm:p-2 rounded-lg transition-colors ${
                isDark ? "hover:bg-gray-800" : "hover:bg-gray-100"
              }`}
              onClick={onProfileClick}
            >
              <User size={18} className="sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>
      </header>

      {showShareModal && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
          
          <div 
            className="fixed inset-0 backdrop-blur-sm bg-black/40 z-[9999]" 
            onClick={onShareModalClose}
          ></div>
          
          
          <div
            className={`relative z-[10000] w-full max-w-sm sm:max-w-md lg:max-w-lg rounded-lg p-4 sm:p-6 shadow-xl ${
              isDark ? "bg-[#1a1a1a] text-white" : "bg-white text-black"
            }`}
          >
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-base sm:text-lg font-semibold">Share Link</h2>
              <button
                onClick={onShareModalClose}
                className={`p-1 rounded-lg ${
                  isDark ? "hover:bg-gray-700" : "hover:bg-gray-100"
                }`}
              >
                <CloseIcon size={18} className="sm:w-5 sm:h-5" />
              </button>
            </div>

            <button
              onClick={handleArchive}
              className={`w-full flex items-center gap-2 px-3 py-2 mb-4 rounded-lg border text-sm sm:text-base ${
                isDark
                  ? "border-gray-600 hover:bg-gray-700"
                  : "border-gray-300 hover:bg-gray-100"
              }`}
            >
              <MessageSquare size={14} className="sm:w-4 sm:h-4" />
              Archive Chat
            </button>

            <div
              className={`flex items-center gap-2 p-2 sm:p-3 rounded-lg mb-4 ${
                isDark ? "bg-gray-700" : "bg-gray-100"
              }`}
            >
              <span className="flex-1 text-xs sm:text-sm font-mono truncate">
                {getShareUrl()}
              </span>
              <button
                onClick={() => handleSharePlatform("copy")}
                className={`p-1 rounded ${
                  isDark ? "hover:bg-gray-600" : "hover:bg-gray-200"
                }`}
              >
                {copySuccess ? (
                  <Check size={14} className="sm:w-4 sm:h-4" />
                ) : (
                  <Copy size={14} className="sm:w-4 sm:h-4" />
                )}
              </button>
            </div>

            <p
              className={`text-xs sm:text-sm mb-4 ${
                isDark ? "text-gray-300" : "text-gray-600"
              }`}
            >
              Anyone with this link can view this page.
            </p>

            <div className="flex justify-center gap-2 sm:gap-3">
              <button
                onClick={() => handleSharePlatform("linkedin")}
                className={`p-2 rounded-lg ${
                  isDark ? "hover:bg-gray-700" : "hover:bg-gray-100"
                }`}
                title="Share on LinkedIn"
              >
                <Linkedin size={18} className="sm:w-5 sm:h-5" />
              </button>
              <button
                onClick={() => handleSharePlatform("whatsapp")}
                className={`p-2 rounded-lg ${
                  isDark ? "hover:bg-gray-700" : "hover:bg-gray-100"
                }`}
                title="Share on WhatsApp"
              >
                <MessageCircle size={18} className="sm:w-5 sm:h-5" />
              </button>
              <button
                onClick={() => handleSharePlatform("mail")}
                className={`p-2 rounded-lg ${
                  isDark ? "hover:bg-gray-700" : "hover:bg-gray-100"
                }`}
                title="Share via Email"
              >
                <Mail size={18} className="sm:w-5 sm:h-5" />
              </button>
              <button
                onClick={() => handleSharePlatform("facebook")}
                className={`p-2 rounded-lg ${
                  isDark ? "hover:bg-gray-700" : "hover:bg-gray-100"
                }`}
                title="Share on Facebook"
              >
                <Facebook size={18} className="sm:w-5 sm:h-5" />
              </button>
              <button
                onClick={() => handleSharePlatform("twitter")}
                className={`p-2 rounded-lg ${
                  isDark ? "hover:bg-gray-700" : "hover:bg-gray-100"
                }`}
                title="Share on Twitter"
              >
                <Twitter size={18} className="sm:w-5 sm:h-5" />
              </button>
              <button
                onClick={() => handleSharePlatform("telegram")}
                className={`p-2 rounded-lg ${
                  isDark ? "hover:bg-gray-700" : "hover:bg-gray-100"
                }`}
                title="Share on Telegram"
              >
                <Send size={18} className="sm:w-5 sm:h-5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ChatHeader;