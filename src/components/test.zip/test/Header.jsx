import React, { useState, useEffect } from "react";
import { Menu, Sparkles, X } from "lucide-react";
import { Link } from "react-router-dom"; // React Router Link

// Button component
const Button = ({ variant = "default", size = "default", className = "", children, onClick, ...props }) => {
  const baseStyles = "inline-flex items-center justify-center rounded-2xl font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none ring-offset-background";
  
  const variants = {
    default: "bg-primary text-primary-foreground hover:bg-primary/90",
    ghost: "hover:bg-accent hover:text-accent-foreground",
    outline: "border border-input hover:bg-accent hover:text-accent-foreground"
  };
  
  const sizes = {
    default: "h-10 py-2 px-4",
    sm: "h-9 px-3 rounded-md",
    lg: "h-11 px-8 rounded-md",
    icon: "h-10 w-10"
  };
  
  return (
    <button
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
      onClick={onClick}
      {...props}
    >
      {children}
    </button>
  );
};

const Header = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) setSidebarOpen(false);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    document.body.style.overflow = sidebarOpen ? "hidden" : "unset";
    return () => { document.body.style.overflow = "unset"; };
  }, [sidebarOpen]);

  return (
    <>
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled 
          ? "bg-white/95 backdrop-blur-xl border-b border-gray-200 shadow-sm" 
          : "bg-white/80 backdrop-blur-xl border-b border-gray-100"
      }`}>
        <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6 xl:px-8">
          <div className="flex items-center justify-between h-14 sm:h-16 lg:h-18">
            {/* Logo */}
            <div className="flex items-center space-x-2 sm:space-x-3 flex-shrink-0">
              <div className="w-8 h-8 sm:w-9 sm:h-9 lg:w-10 lg:h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg sm:rounded-xl flex items-center justify-center shadow-lg">
                <Sparkles className="text-white w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <span className="text-lg sm:text-xl lg:text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Bharat AI
              </span>
            </div>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center space-x-6 xl:space-x-8">
              <Link to="/test/features" className="text-gray-600 hover:text-blue-600 font-medium text-sm xl:text-base transition-colors">Features</Link>
              <Link to="/test/tools" className="text-gray-600 hover:text-blue-600 font-medium text-sm xl:text-base transition-colors">AI Tools</Link>
              <Link to="/test/pricing" className="text-gray-600 hover:text-blue-600 font-medium text-sm xl:text-base transition-colors">Pricing</Link>
              <Link to="/test/about" className="text-gray-600 hover:text-blue-600 font-medium text-sm xl:text-base transition-colors">About</Link>
              <Link to="/test/contact" className="text-gray-600 hover:text-blue-600 font-medium text-sm xl:text-base transition-colors">Contact us</Link>
            </nav>

            {/* Buttons */}
            <div className="flex items-center space-x-1 sm:space-x-2">
              <Link to="/test/signin" className="hidden md:block">
                <Button variant="ghost" className="text-gray-600 hover:text-blue-600 font-medium text-sm lg:text-base px-3 lg:px-4">Sign In</Button>
              </Link>
              <Link to="/test/chat" className="hidden sm:block">
                <Button className="bg-blue-600 hover:bg-blue-700 text-white rounded-full px-3 sm:px-4 lg:px-6 shadow-lg text-sm lg:text-base">
                  Get Started
                </Button>
              </Link>
              <Button variant="ghost" size="icon" className="lg:hidden inline-flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10" onClick={toggleSidebar}>
                <Menu className="w-4 h-4 sm:w-5 sm:h-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Sidebar */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={toggleSidebar}></div>
          <div className="absolute top-0 right-0 w-72 sm:w-80 md:w-96 h-full bg-white shadow-2xl z-50 overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center p-4 sm:p-6 border-b border-gray-100">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Sparkles className="text-white w-4 h-4" />
                </div>
                <span className="text-lg font-bold text-blue-600">Bharat AI</span>
              </div>
              <button onClick={toggleSidebar} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <X className="w-5 h-5 text-gray-700" />
              </button>
            </div>

            <nav className="flex flex-col p-4 sm:p-6 space-y-1">
              <Link to="/test/features" onClick={toggleSidebar} className="flex items-center px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 font-medium rounded-lg">Features</Link>
              <Link to="/test/tools" onClick={toggleSidebar} className="flex items-center px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 font-medium rounded-lg">AI Tools</Link>
              <Link to="/test/pricing" onClick={toggleSidebar} className="flex items-center px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 font-medium rounded-lg">Pricing</Link>
              <Link to="/test/about" onClick={toggleSidebar} className="flex items-center px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 font-medium rounded-lg">About</Link>
              <Link to="/test/contact" onClick={toggleSidebar} className="flex items-center px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 font-medium rounded-lg">Contact us</Link>

              <div className="border-t border-gray-200 my-4"></div>

              <Link to="/test/signin" onClick={toggleSidebar} className="flex items-center px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 font-medium rounded-lg">Sign In</Link>
              <Link to="/test/chat" className="mt-4">
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-3xl shadow-lg" onClick={toggleSidebar}>
                  Get Started
                </Button>
              </Link>
            </nav>
          </div>
        </div>
      )}

      <div className="h-14 sm:h-16 lg:h-18"></div>
    </>
  );
};

export default Header;
